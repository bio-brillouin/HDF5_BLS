from src.Load_data import Load_Data
from src.Treat import Treat
from src.Wraper import Wraper