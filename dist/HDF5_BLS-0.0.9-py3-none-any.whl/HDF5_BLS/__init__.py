"""
HDF5_BLS (c) is a library to manage and treat Brillouin Scattered spectra
using the HDF5 file format.

HDF5_BLS is licensed under a MIT License.

You should have received a copy of the license along with this work. If not, 
see <https://choosealicense.com/licenses/mit/>.
"""